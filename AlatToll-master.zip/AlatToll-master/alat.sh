#!/bin/bash
#############################
#  ALAT KEPERLUAN ONLINE                 #
#############################
clear
blue='\033[34;1m'
green='\033[32;1m'
purple='\033[35;1m'
cyan='\033[36;1m'
red='\033[31;1m'
white='\033[37;1m'
yellow='\033[33;1m'
clear
echo "\033[36;1m[]=====================================================[]"|lolcat
echo "\033[37;1m[] AUTHOR :  RISKI DARMAWAN                            []"|lolcat
echo "\033[35;1m[] W A    :   085836465872                             []"|lolcat
echo "\033[36;1m[] NO HP  : 085835295133                               []"|lolcat
echo "\033[31;1m[] PESAN  : GUNAKAN TOOLS INI DENGAN BIJAK             []"|lolcat
echo "\033[36;1m[]=====================================================[]"|lolcat
echo "\033[36;1m-------=========[ KEPERLUAN ALAT ONLINE ]========------"|lolcat

                       echo $red"            IlıılıIlılıl MENU IlıılıIlılıl"|lolcat
                       echo $red"                     凸冖へ冖凸"|lolcat
                       
         
echo $red"          <©>=========================<®>"
echo $red"          ( 1 ) HACK FB NARGET"|lolcat
echo $green"          <©>=========================<®>"
echo $red"          ( 2 ) HACK FB MASSAL"|lolcat
echo $red"          <©>=========================<®>"
echo $red"          ( 3 ) INSTALL OSIF V.1"|lolcat
echo $green"          <©>=========================<®>"
echo $red"          ( 4 ) INSTALL OSIF V.2"|lolcat
echo $red"          <©>=========================<®>"
echo $red"          ( 5 ) PHISING FACEBOOK V.1"|lolcat
echo $green"          <©>=========================<®>"
echo $red"          ( 6 ) PHISING FACEBOOK V.2"|lolcat
echo $red"          <©>=========================<®>"
echo $red"          ( 7 ) PHISING GAME ONLINE"|lolcat
echo $green"          <©>=========================<®>"
echo $red"          ( 8 ) PHISING FACEBOOK V.3"|lolcat
echo $red"          <©>=========================<®>"
echo $red"          ( 9 ) SPAM SMS"|lolcat
echo $green"          <©>=========================<®>"
echo $red"          ( 10 ) SPAM WA + CALL"|lolcat
echo $red"          <©>=========================<®>"
echo $red"          ( 11 ) SPAM IG"|lolcat
echo $green"          <©>=========================<®>"
echo $red"          ( 12 ) TEMBAK QUOTA XL"|lolcat
echo $red"          <©>=========================<®>"
echo $red"          ( 13 ) HACK WIFI (ROOT#GAN)"|lolcat
echo $green"          <©>=========================<®>"
echo $red"          ( 14 ) LACAK ORANG DENGAN EMAIL"|lolcat
echo $red"          <©>=========================<®>"
echo $red"          ( 15 ) INSTALL BAHAN DULU COK"|lolcat
echo $green"          <©>=========================<®>"
echo $red"          ( 16 ) HACK WHATSAPP"|lolcat
echo $red"          <©>=========================<®>"
echo $red"          ( 17 ) APK DOWNLOADER"|lolcat
echo $green"          <©>=========================<®>"
echo $red"          ( 18 ) INSTALL TOOLS V.1"|lolcat
echo $red"          <©>=========================<®>"
echo $red"          ( 19 ) INSTALL TOOLS V.2"|lolcat
echo $green"          <©>=========================<®>"
echo $red"          ( 20 ) DEFACE"|lolcat
echo $red"          <©>=========================<®>"
echo $red"          ( 21 ) DIAL PAKET MURAH (ISAT)"|lolcat
echo $green"          <©>=========================<®>"
echo $red"          ( 22 ) DONLOD VIDIO DARI YT"|lolcat
echo $red"          <©>=========================<®>"
echo $red"          ( 23 ) LITE CALCULATOR"|lolcat
echo $green"          <©>=========================<®>"
echo $red"          ( 24 ) INSTALL ANU"|lolcat
echo $red"          <©>=========================<®>"
echo $red"          ( 25 ) NUYUL KUBIK WORK"|lolcat
echo $green"          <©>=========================<®>"
echo $red"          ( 00 ) [ KELUAR / EXIT ]"|lolcat
echo $red"          <©>=========================<®>"
echo "\033[33;1m"
read -p "      √={PILIH SESUAI SELERA}===> : " c;

if [ $c = 1 ]
then
clear
python2 fb2.py
fi

if [ $c = 2 ]
then
clear
git clone https://github.com/hnov7/mbf
cd mbf
python2 mbf.py
fi

if [ $c = 3 ]
then
clear
pkg update && pkg upgrade
pip2 install mechanize
pkg install git
pkg install python2
pip2 install requirements.txt
git clone https://github.com/xHak9x/fbi
cd fbi
python2 fbi.py
fi

if [ $c = 4 ]
then
clear
pkg update && pkg upgrade
pkg update upgrade
pkg install git python2
git clone https://github.com/ciku370/OSIF
cd OSIF
python2 osif.py
fi

if [ $c = 5 ]
then
clear
apt update
apt upgrade
git clone https://github.com/thelinuxchoice/shellphish.git
cd shellphish
bash shellphish.sh
fi

if [ $c = 6 ]
then
clear
apt update
apt upgrade
git clone https://github.com/thelinuxchoice/blackeye.git
cd blackeye
bash blackeye.sh
fi

if [ $c = 7 ]
then
clear
apt install python2
apt install apache2
apt install git php unzip
git clone https://github.com/Senitopeng/PhisingOnline.git
cd PhisingOnline
unzip PhisingOnline.zip
python2 online.py
fi

if [ $c = 8 ]
then
clear
apt update
apt upgrade
git clone https://github.com/UndeadSec/SocialFish.git
cd SocialFish
chmod +x *
pip2 install -r requirements.txt
python2 SocialFish.py
fi

if [ $c = 9 ]
then
clear
pip2 install requests
apt install nano
apt install git
git clone https://github.com/Senitopeng/SpamSms.git
cd SpamSms
chmod +x mantan.py 
python2 mantan.py
fi

if [ $c = 10 ]
then
clear
echo $red"KALAU MAU SPAM WA KETIK php wa.php"|lolcat
echo $red"KALAU MAU SPAM CALL KETIK php call.php"|lolcat
apt update -y
apt upgrade -y
apt install git
apt install php
git clone https://github.com/siputra12/prank
cd prank
php wa.php
fi

if [ $c = 11 ]
then
clear
apt update
apt upgrade
apt install git
git clone 
https://github.com/thelinuxchoice/instaspam.git
cd instaspam
bash instaspam.sh
fi

if [ $c = 12 ]
then
clear
pip2 install requests
pkg install python
pkg install git
pip install requests
git clone https://github.com/albertoanggi/xl-py.git
cd xl-py
python app.py
fi

if [ $c = 13 ]
then
clear
apt update + apt upgrade
pkg install git
git clone https://github.com/esc0rtd3w/wifi-hacker
cd wifi-hacker/
chmod +x wifi-hacker.sh
./wifi-hacker.sh
fi

if [ $c = 14 ]
then
clear
$apt update
apt upgrade
pkg install php
pkg install git
pkg install bash
pkg instal curl
git clone https://github.com/thelinuxchoice/infog
cd infog
bash infog.sh
fi

if [ $c = 15 ]
then
clear
pkg update
pkg upgrade
pkg install git
pkg install php
pkg install figlet
pkg install toilet
pkg install python2
pkg install lolcat
pip2 install requests
pip2 install termcolor
pip2 install --upgrade pip
figlet -f slant "SUKSES"|lolcat
sh alat.sh
fi

if [ $c = 16 ]
then
clear
pkg install python2
pkg install nano
pkg install php
pkg install git
git clone https://github.com/AndriGanz/whatshack
cd whatshack
sh whatshack.sh
fi

if [ $c = 17 ]
then
clear
git clone https://github.com/karjok/APKDOWN
cd APKDOWN
python APKDown.py
fi

if [ $c = 18 ]
then
clear
git clone https://github.com/FR13ND8/tools
cd tools
sh tools.sh
fi

if [ $c = 19 ]
then
clear
git clone https://github.com/FR13ND8/TOOLSv2
cd TOOLSv2
sh TOOLSv2.sh
fi

if [ $c = 20 ]
then
clear
git clone https://github.com/FR13ND8/Deface
cd Deface
python2 ganss.py
fi

if [ $c = 21 ]
then
clear
figlet -f slant " 3" |lolcat
figlet -f slant "2" |lolcat
figlet -f slant "1" |lolcat
clear
echo $blue"LUWAK WHITE COPI PASSWORD NYA ??"|lolcat
echo $blue"BILA TIDAK TAU MAKA AKAN KEMBALI LAGI SEMULA"|lolcat
echo $blue"PASSWORDNYA ( mantap ) ITU GAN"|lolcat
echo $blue"HEHEHEHEHEHEHE"|lolcat
echo "\033[33;1m"
read -p " [ Password ]==> : " pass
if [ $pass = "mantap" ]
then
sleep 1
clear
else
echo "      \033[32;1m[\033[31;1m!\033[32;1m]\033[34;1m----\033[35;1m[ \033[31;1mPassword Salah Kontol\033[35;1m]\033[34;1m----\033[32;1m[\033[31;1m!\033[32;1m]"
sleep 1
clear
sh alat.sh
fi
echo "*123*111#"|lolcat
echo "*993*699#"|lolcat
echo "*363*111*4#"|lolcat
echo "*123*100*1#"|lolcat
echo "*123*100*2#"|lolcat
echo "*123*100*3#"|lolcat
echo "*123*100*5#"|lolcat
echo "*990*250*1*1#"|lolcat
echo "*990*250*2*1#"|lolcat
echo "*990*250*2*2#"|lolcat
echo "*292#"|lolcat
echo "*123*3*2*3#"|lolcat
echo $red" CUMAN ITU YANG WE TAU -_-"|lolcat
echo "\033[34;1m"
read -p "........TEKAN ENTER UNTUK BALIK LAGI.......... " l;
sh alat.sh
fi

if [ $c = 22 ]
then
clear
git clone https://github.com/karjok/SYTD
cd SYTD
python sytd.py
fi

if [ $c = 23 ]
then
clear
git clone https://github.com/karjok/Litor
cd Litor
python litor.py
fi

if [ $c = 24 ]
then
clear
git clone https://github.com/karjok/anu
cd anu
python anu.py
fi

if [ $c = 25 ]
then
clear
read -p " TUNGGU GAN [ ENTER ] " +;
pkg update && pkg upgrade
pkg install nano
pkg install git
pkg install php
termux-setup-storage
git clone https://github.com/segi3channel/guludug
cd guludug
echo "\033[36;1m"
read -p "......kalau sudah mengeditnya silah kan tekan CTRL + y lalu enter [ ENTER ]...." +;
nano cfg.php
php bot.php
fi

if [ $c = 00 ]
then
clear
echo "SAMPAI JUMPA LAGI HACKER"|lolcat
echo " JANGAN LUPA SHARE TOOLS INI OK"|lolcat
echo "GUNAKAN LAH DENGAN BIJAK"|lolcat
echo " INCARLAH SESUATU YG MUSTAHIL"|lolcat
echo "GOOD BY"|lolcat
exit
logout
fi